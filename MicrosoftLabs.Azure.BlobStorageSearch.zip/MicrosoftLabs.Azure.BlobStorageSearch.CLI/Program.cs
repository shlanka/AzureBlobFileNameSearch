﻿using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftLabs.Azure.BlobStorageSearch
{
    class Program
    {
        const string blobName = "Blob Name: ";
        const string lmDate = "Last Modified Date: ";
        const string uri = "Blob URL: ";

        static void Main(string[] args)
        {
            Console.WriteLine("Enter Sas Uri of the container(Read and List Access required):");
            var sasUri = Console.ReadLine();

            Console.WriteLine("Enter the filter value:");
            var filter = Console.ReadLine();

            Search(sasUri, filter);

            Console.ReadLine();
        }

        private static void Search(string sasUri, string filter)
        {
            var cloudBlobContainer = CloudBlobContainerFactory.GetCloudBlobContainerInstance(new BlobSearchProperties { SasUri = sasUri });
            var filteredList = cloudBlobContainer.FilterByName(filter, StringComparison.OrdinalIgnoreCase);
            Display(filteredList);
        }

        private static void Display(IEnumerable<CloudBlockBlob> cloudBlob)
        {
            Console.WriteLine("Getting Results.... This may take a while");

            StringBuilder builder = new StringBuilder();
            long count = 0;
            foreach (var blob in cloudBlob)
            {
                count++;
                builder.Append(blobName);
                builder.Append(blob.Name);
                Console.WriteLine(builder.ToString());
                builder.Clear();

                builder.Append(lmDate);
                builder.Append(blob.Properties.LastModified.Value.ToString());
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine(builder.ToString());
                builder.Clear();

                builder.Append(uri);
                builder.Append(blob.Uri.ToString());
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(builder.ToString());
                builder.Clear();

                Console.ResetColor();
                Console.WriteLine();
                Console.WriteLine();
            }

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"Done: {count} results found");
        }
    }
}
