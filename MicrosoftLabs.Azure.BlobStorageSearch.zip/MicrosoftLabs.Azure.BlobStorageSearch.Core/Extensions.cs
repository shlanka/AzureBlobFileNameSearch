﻿using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftLabs.Azure.BlobStorageSearch
{
    public static class Extensions
    {
        public static IEnumerable<CloudBlockBlob> FilterByName(
            this CloudBlobContainer blobContainer,
            string name, 
            StringComparison comparison) =>
           BlobSearch.Filter(blobContainer, blob => blob.Name.IndexOf(name, comparison) >= 0);
    }
}
