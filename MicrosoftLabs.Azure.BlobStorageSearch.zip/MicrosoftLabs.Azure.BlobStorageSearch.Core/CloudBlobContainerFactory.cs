﻿using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftLabs.Azure.BlobStorageSearch
{
    public static class CloudBlobContainerFactory
    {
        public static CloudBlobContainer GetCloudBlobContainerInstance(BlobSearchProperties searchProperties)
        {
            if (searchProperties.AuthenticationMode == AuthenticationMode.SharedAccessToken)
                return new CloudBlobContainer(new Uri(searchProperties.SasUri));

            throw new NotSupportedException("AuthenticationMode not supported");
        }
    }
}
