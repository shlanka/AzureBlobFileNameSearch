﻿using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftLabs.Azure.BlobStorageSearch
{
    public static class BlobSearch
    {
        public static IEnumerable<CloudBlockBlob> Filter(CloudBlobContainer blobContainer, Func<CloudBlockBlob, bool> filterPredicate) =>
            blobContainer.ListBlobs(useFlatBlobListing: true)
                .OfType<CloudBlockBlob>()
                .Where(filterPredicate);
    }
}
