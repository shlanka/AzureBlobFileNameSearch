﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MicrosoftLabs.Azure.BlobStorageSearch
{
    public class BlobSearchProperties
    {
        public AuthenticationMode AuthenticationMode = AuthenticationMode.SharedAccessToken;
        public string SasUri;
    }

    public enum AuthenticationMode
    {
        SharedAccessToken=1
    }
}